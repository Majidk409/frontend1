const form = document.querySelector("form");
const password = document.getElementById("newpassword");
const username = document.querySelector("#name");
const retypepass = document.getElementById("retypepassword");
const email = document.getElementById("email");
const age = document.getElementById("age");
form.addEventListener('submit', (e) => {
    e.preventDefault();
    checkInputs();
});
function checkInputs(){
    //getting values from inputs
    var usernamevalue = username.value.trim();
    const passwordvalue = password.value.trim();
    const retypepassvalue = retypepass.value.trim();
    const emailvalue = email.value.trim();
    const agevalue = age.value.trim();
    if(usernamevalue === "" ){
        
        //show error
        //add error class
        setErrorFor(username,'username cannot be Nil');
        

    }else{
        //add success class
        setSuccessFor(username);
    }
    
    if(retypepassvalue === passwordvalue && passwordvalue !=''){

        setSuccessFor(retypepass);
    }else{
        //add error class
        
        setErrorFor(retypepass,'password mismatch');

    }
    if(emailvalue === "" ){
        
        //show error
        //add error class
        setErrorFor(email,'email cannot be Nil');
        

    }else{
        //add success class
        setSuccessFor(email);
    }
    if(agevalue === "" || agevalue <=10 || agevalue >80){
        
        //show error
        //add error class
        setErrorFor(age,"sorry can't be admitted");
        

    }else{
        //add success class
        setSuccessFor(age);
    }

}
function setErrorFor(input, message){
    const formControl = input.parentElement //.form-control
    const small = formControl.querySelector('small');
    //adding error in small tag
    small.innerHtml = message;
    //add error class
    formControl.className = 'form-control error';
}
function setSuccessFor(input){
    const formControl = input.parentElement;//.form-control
    formControl.className = 'form-control success';
}
