//EVENTS

//mouse
//  Mouse objects

let click = document.querySelector(".text");
let mouse = document.querySelector(".image");
// Mouse functions

function oversetnew ()
{
  mouse.src = "images/doctor5.png";
}

function outsetold (){ 
  mouse.src = "images/doctor3.png";
}

function mpress(){
    click.innerHTML = "onclick has triggered";
}
//keyboard
//keyboard objects

let keyp = document.querySelector("#text1");
let keyu = document.querySelector("#text3"); 
let keyd = document.querySelector("#text2");
let para = document.querySelector("#para");

//keyboard functions

keyp.onkeypress = paracontent;//parameter passing to paracontent function
keyu.onkeyup = paracontent;
keyd.onkeydown = paracontent;
function paracontent(e){
   para.innerHTML += e.key;//e.code||e||e.key can be used
}

//FORM EVENTS
//form objects

let t1 = document.querySelector("#text4");
let f = document.querySelector("#frm");
let m = document.querySelector("#message");
//form functions

t1.addEventListener("focus",(e) => {
    e.target.style.background = "#ff96ad";
});

t1.addEventListener("blur" ,(e) => {
    e.target.style.background = '';
});

f.addEventListener("submit",(e) => {
   e.preventDefault();
   m.innerHTML = "form submitted"; 
   
});

//window or document event
//load object

let image = document.querySelector("#img");

//load function

image.addEventListener("load",(e) => {
  console.log("image has been loaded");
  document.querySelector("h5").innerHTML = "height : "+image.height+"  width: "+image.width;
});

//event bubbling
//bubble objects
let parrent = document.querySelector("#parrent");
let  child = document.querySelector("#child");
parrent.addEventListener("click",(e) => {
      console.log("parrent clicked");
});
child.addEventListener("click",(e) => {
      console.log("child clicked");
});