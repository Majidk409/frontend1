
const form = document.querySelector("form");
const password = document.getElementById("newpassword");
const username = document.querySelector("#name");
const retypepass = document.getElementById("retypepassword");
const email = document.getElementById("email");
const age = document.getElementById("age");
// const place = document.getElementById("place");
form.addEventListener('submit', (e) => {
    e.preventDefault();
    checkInputs();
});
function checkInputs(){
    //getting values from inputs
    var usernamevalue = username.value.trim();
    const passwordvalue = password.value.trim();
    const retypepassvalue = retypepass.value.trim();
    const emailvalue = email.value.trim();
    const agevalue = age.value.trim();
    const placevalue = place.value.trim();
    if(usernamevalue === "" ){

        //show error
        //add error class
        setErrorFor(username,'username cannot be Nil');


    }else{
        //add success class
        setSuccessFor(username);
    }

    if(retypepassvalue === passwordvalue && passwordvalue !=''){

        setSuccessFor(retypepass);
    }else{
        //add error class

        setErrorFor(retypepass,'password not allowed');

    }
    if(emailvalue === "" ){

        //show error
        //add error class
        setErrorFor(email,"fill a vallied email");


    }else{
        //add success class
        setSuccessFor(email);
    }
    if(agevalue === "" || agevalue >=11){

        //show error
        //add error class
        setErrorFor(age,"patient can't be admitted");


    }else{
        //add success class
        setSuccessFor(age);
    }
    // (placevalue === '')?setErrorFor(place,"please provide your place"):setSuccessFor(input);

}
function setErrorFor(input, message){
    const formControl = input.parentElement //.form-control
    const small = formControl.querySelector('small');
    //adding error in small tag
    small.innerHTML = message;
    //add error class
    formControl.className = 'form-control error';
}
function setSuccessFor(input){
    const formControl = input.parentElement;//.form-control
    formControl.className = 'form-control success';
}
//EVENTS

//mouse
//  Mouse objects

  let click = document.querySelector(".text");
  let mouse = document.querySelector(".image");
// Mouse functions

  function oversetnew ()
  {
    mouse.src = "images/doctor5.png";
  }

  function outsetold (){ 
    mouse.src = "images/doctor3.png";
  }

  function mpress(){
      click.innerHTML = "onclick has triggered";
  }
  //keyboard
  //keyboard objects

  let keyp = document.querySelector("#text1");
  let keyu = document.querySelector("#text3"); 
  let keyd = document.querySelector("#text2");
  let para = document.querySelector("#para");
  
  //keyboard functions

 keyp.onkeypress = paracontent;//parameter passing to paracontent function
 keyu.onkeyup = paracontent;
 keyd.onkeydown = paracontent;
 function paracontent(e){
     para.innerHTML += e.key;//e.code||e||e.key can be used
 }

 //FORM EVENTS
 //form objects
  
  let t1 = document.querySelector("#text4");
  let f = document.querySelector("#frm");
  let m = document.querySelector("#message");
  //form functions
 
  t1.addEventListener("focus",(e) => {
      e.target.style.background = "#ff96ad";
  });

  t1.addEventListener("blur" ,(e) => {
      e.target.style.background = '';
  });

f.addEventListener("submit",(e) => {
     e.preventDefault();
     m.innerHTML = "form submitted"; 
     
 });
 
 //window or document event
//load object

 let image = document.querySelector("#img");

//load function

 image.addEventListener("load",(e) => {
    console.log("image has been loaded");
    document.querySelector("h5").innerHTML = "height : "+image.height+"  width: "+image.width;
});

//event bubbling
//bubble objects
let parrent = document.querySelector("#parrent");
let  child = document.querySelector("#child");
parrent.addEventListener("click",(e) => {
        console.log("parrent clicked");
});
child.addEventListener("click",(e) => {
        console.log("child clicked");
});
  

 
    