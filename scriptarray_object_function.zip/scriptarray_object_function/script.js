
    
       
        function Add(input1,input2)
        {
            var input1 =  parseFloat(parseFloat(document.querySelector(".input1").value));
            var input2 =  parseFloat(parseFloat(document.querySelector(".input2").value));
            if(!isNaN(input1) && (input1.length || input2.length) != 0) alert(input1+input2); 
            else alert(" PLEASE PROVIDE SUITABLE VALUES!!");
           
               

        }

        function Multiply(input1,input2)
        {
            var input1 =  parseFloat(parseFloat(document.querySelector(".input1").value));
            var input2 =  parseFloat(parseFloat(document.querySelector(".input2").value));
            if(!isNaN(input1) && (input1.length || input2.length) != 0 ) alert (input2*input1); 
            else alert(" PLEASE PROVIDE SUITABLE VALUES!!");
            
        }

        function Divide(input1,input2)
        {
            var input1 =  parseFloat(parseFloat(document.querySelector(".input1").value));
            var input2 =  parseFloat(parseFloat(document.querySelector(".input2").value));
            if(!isNaN(input1) && ((input1.length || input2.length) != 0)  && (input2 != 0)) alert(Math.round(input1/input2));  
            else if(input2 === 0 ) alert("DIVISION BY ZERO IS NOT PERMITTED!");
                else alert(" PLEASE PROVIDE SUITABLE VALUES!!");
        }

        function Subtract(input1,input2)
        {
            var input1 =  parseFloat(parseFloat(document.querySelector(".input1").value));
            var input2 =  parseFloat(parseFloat(document.querySelector(".input2").value));
            if(!isNaN(input1) && (input1.length || input2.length) != 0 ) alert (input1-input2); 
            else alert(" PLEASE PROVIDE SUITABLE VALUES!!");
            
        }
        
        function compoundInterest()
        {
            //principleAmount
            var p = parseFloat(document.querySelector(".input3").value);
            //timePeriod
            var t = parseFloat(document.querySelector(".input5").value);
            //AnnualInterest
            var r = parseFloat(document.querySelector(".input4").value);
            //compoundedTimes
            var n = parseFloat(document.querySelector(".input6").value);
            var amount = p * (Math.pow((1 + (r / n)), (n * t)));
            var interest = Math.round(amount - p);
            alert(interest);
        }